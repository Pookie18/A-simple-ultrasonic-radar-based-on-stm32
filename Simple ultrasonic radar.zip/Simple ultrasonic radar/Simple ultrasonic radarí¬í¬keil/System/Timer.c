#include "stm32f10x.h"                  // Device header
#include "Timer.h"

extern uint16_t Time;   //Time变量在HCSR04.c文件中定义

void Timer_Init()
{
 	Time = 0;
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);	//选择APB1总线下的定时器Timer3
	
	TIM_InternalClockConfig(TIM3);		//TIM3使用内部时钟
										//默认使用内部时钟，不写这句代码也没关系
	
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;		//时钟1分频
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;		//计数模式，此处为向上计数
	TIM_TimeBaseInitStructure.TIM_Period = 7200 - 1;		//ARR 1 = 0.0001S，自动重装器的值
	TIM_TimeBaseInitStructure.TIM_Prescaler = 0;		//PSC，预分频器的值
	TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;		//高级计时器特有，重复计数
	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseInitStructure);
	
	TIM_ClearFlag(TIM3, TIM_FLAG_Update);
	TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE);		//使能中断
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);		//将中断优先级分为两组，即组1和组2。

	
	NVIC_InitTypeDef NVIC_InitStructure;// 定义一个NVIC_InitTypeDef结构体变量，用于初始化中断控制器
	NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;// 设置中断通道为TIM3的IRQn中断
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;// 使能中断通道
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;// 设置中断优先级为2，表示高优先级
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;// 设置中断子优先级为1，表示低优先级
	NVIC_Init(&NVIC_InitStructure);// 使用NVIC_Init函数初始化中断控制器
	
	TIM_Cmd(TIM3, ENABLE);// 使能定时器TIM3

}

void TIM3_IRQHandler(void)		// 定时器3的中断函数
{
    if(TIM_GetITStatus(TIM3, TIM_IT_Update) == SET) // 检查定时器3的更新中断标志位是否被设置
    {
        if (GPIO_ReadInputDataBit(Echo_Port, Echo_Pin) == 1) // 读取回声传感器端口上的引脚状态
        {
            Time++; // 如果引脚状态为高电平，则增加时间计数器
        }
        TIM_ClearITPendingBit(TIM3, TIM_IT_Update);		// 清空标志位，表示中断已经处理完毕
    }
}

