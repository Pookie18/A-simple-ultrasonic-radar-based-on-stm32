#include "stm32f10x.h"                  // Device header
#include "key.h"  
#include "Delay.h" 
#include "LED.h" 
#include "OLED.h" 
#include "Servo.h"
#include "Key.h"
#include "HCSR04.h"
#include "Timer.h"
#include "IC.h"

float Angle;//旋转的角度
short T;//超声波检测到的距离

int main(void)
{
	//各个模块的初始化
	Key_Init();
	LED_Init();
	OLED_Init();
	Servo_Init();
	HCSR04_Init();
	IC_Init();
	

	
	while(1)
	{	

		if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_1)==0)//按键按下启动
		{	
			Delay_ms(20);
			while(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_1)==0);
			Delay_ms(20);
			//延时消抖
			
			if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_11)==0)
			{
				Delay_ms(100);
				GPIO_SetBits(GPIOB, GPIO_Pin_11);
				
				OLED_Show12864BMP(0);
				Delay_ms(1000);
				OLED_Clear();
				
				for(int i=0;i<=63;i++)
				{
					OLED_GDrawPoint(i,63);
					OLED_GDrawPoint(127-i,63);
					OLED_GDrawPoint(63,i);
					//OLED_DrawPoint(i,i);
					//OLED_DrawPoint(127-i,i);
				}		
				OLED_Refresh();

				while(Angle<180)
				{
					//舵机角度控制
					float i=0.5;
					Angle+=i;				
//					OLED_ShowString(2,1, "Angle:");
//					OLED_ShowNum(2,7,Angle,3);
					Servo_SetAngle(Angle);

					
					//超声波测距--定时器中断实现，调用Timer.h
//					T = HCSR04_GetValue();
//					OLED_ShowString(3, 1, "Distance:");
//					OLED_ShowString(3, 13, "cm");
//					OLED_ShowNum(3, 10, T, 3);
					
					//超声波测距--输入捕获实现，调用IC.h
					T=GetLength(); 
//					OLED_ShowString(3, 1, "Distance:");
//					OLED_ShowString(3, 13, "cm");
//					OLED_ShowNum(3, 10, T, 3);
					
					//OLED_ShowNum(0, 0, Angle, 3);
					//T = (short)(T/50*63);
					OLED_Draw(Angle,T);//传入角度和距离，计算坐标
					
					Delay_ms(30);
				}	
		
			}
			else
			{
				Delay_ms(100);
				GPIO_ResetBits(GPIOB, GPIO_Pin_11);
				
				Angle=0;
				Servo_SetAngle(Angle);
				OLED_GClear();
				OLED_Refresh();
//				OLED_ShowString(2,1, "Angle:");
//				OLED_ShowNum(2,7,Angle,3);
			}

		}
	}
}
