#include "stm32f10x.h"                  // Device header

// 初始化PWM功能
void PWM_Init(void)
{
    // 使能GPIOA时钟
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    
    // 定义GPIO初始化结构体
    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP; // 复用推挽输出
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1; // 使用GPIOA的第1个引脚
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; // GPIO速度50MHz
    GPIO_Init(GPIOA, &GPIO_InitStructure); // 初始化GPIO
	
	
    // 使能TIM2时钟
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
	
    // 配置TIM2为内部时钟
    TIM_InternalClockConfig(TIM2);
    
    // 定义TIM时间基础结构体
    TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
    TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1; // 时钟分频因子
    TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up; // 向上计数模式
    TIM_TimeBaseInitStructure.TIM_Period = 20000 - 1; // 自动重装载寄存器的值，决定计数器计数到多少时重新开始
    TIM_TimeBaseInitStructure.TIM_Prescaler = 72 - 1; // 用于设置计数器的分频，决定计数器时钟频率
    TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0; // 重复计数器的值
    TIM_TimeBaseInit(TIM2, &TIM_TimeBaseInitStructure); // 初始化TIM2
    
    // 定义TIM通道结构体
    TIM_OCInitTypeDef TIM_OCInitStructure;	
    TIM_OCStructInit(&TIM_OCInitStructure);	 // 初始化TIM_OCInitStructure
    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1; 	// PWM模式1
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; // 输出极性为高
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; // 使能输出
    TIM_OCInitStructure.TIM_Pulse = 0; // 设定捕获/比较寄存器的值，决定输出的占空比
    TIM_OC2Init(TIM2, &TIM_OCInitStructure); // 初始化TIM2的通道2
    
    // 使能TIM2
    TIM_Cmd(TIM2, ENABLE);
}

void PWM_SetCompare2(uint16_t Compare)
{
	TIM_SetCompare2(TIM2, Compare);
}
