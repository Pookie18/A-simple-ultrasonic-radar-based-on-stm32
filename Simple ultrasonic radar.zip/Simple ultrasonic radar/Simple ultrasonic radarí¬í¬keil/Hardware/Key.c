#include "stm32f10x.h"                  // Device header
#include "Delay.h"

// 初始化按键模块
void Key_Init(void)
{
	//使用端口PB_1   
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);// 使能GPIOB时钟   
   
    GPIO_InitTypeDef GPIO_InitStructure;// 定义GPIO初始化结构体    
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;// 设置GPIO模式为上拉输入    
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;// 设置引脚为GPIOB_Pin_1    
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;// 设置引脚输出速度为50MHz（输入模式下没用）
    GPIO_Init(GPIOB, &GPIO_InitStructure);// 初始化GPIOB
}

