#ifndef __OLED_H
#define __OLED_H

//�Ѿ�д�ò��ҿ���ʹ�õĺ���
void OLED_Init(void);
void OLED_Clear(void);
void OLED_On(void);
void OLED_ShowChar(uint8_t Line, uint8_t Column, char Char);
void OLED_ShowString(uint8_t Line, uint8_t Column, char *String);
void OLED_ShowNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length);
void OLED_ShowSignedNum(uint8_t Line, uint8_t Column, int32_t Number, uint8_t Length);
void OLED_ShowHexNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length);
void OLED_ShowBinNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length);
void OLED_ShowChinese(unsigned int x,unsigned int y,unsigned int no);
void OLED_Show12864BMP(uint8_t num);
void OLED_Refresh(void);
void OLED_GFill(void);
void OLED_GClear(void);
void OLED_GDrawPoint(unsigned char x,unsigned char y);
void OLED_GClearPoint(unsigned char x,unsigned char y);

//ѧϰ&����ʹ��,��δ��ɵĺ���
void Yanshi(void);
void OLED_Draw(unsigned short angle,unsigned short distance);

#endif
