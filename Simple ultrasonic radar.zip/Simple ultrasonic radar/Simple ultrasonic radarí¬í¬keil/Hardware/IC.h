#ifndef __IC_H
#define __IC_H

void IC_Init(void);

#endif
